#include<iostream>
#include<vector>
#include "MyFunctions.h"

int main() {
	//Menu();
	//char myTime[1000] = { 0 };
	//char fileName[1000] = { 0 };
	pcapFileHeader_t* pcapfileheader = new pcapFileHeader_t;
	pcap_pkthdr* ptk_header = new pcap_pkthdr;
	FramHeader_t* framheader = new FramHeader_t;
	IPHeader_t* ipheader = new IPHeader_t;
	TCPHeader_t* tcpheader = new TCPHeader_t;
	

	std::string path;
	if (!(std::cin >> path)) {
		printf("error---worng file path\n");
		exit(-1);
	}
	std::string filename = GetPcapFileName(path);
	printf_s("filename is %s\n", filename.c_str());
	if (!IsPcapFile(filename)) {
		printf("error---is not pcap file\n");
		exit(-1);
	}
	//std::ifstream pcapfile(path, std::ios::binary | std::ios_base::in);
	//if (!pcapfile.is_open()) {
	//	printf("error---file can not open\n");
	//	exit(-1);
	//}
	//if (!pcapfile.eof()) {
	//	pcapfile  >> pcapfileheader->magic>>pcapfileheader->version_major>>pcapfileheader->version_minor
	//		>>pcapfileheader->thiszone>>pcapfileheader->snaplen>>pcapfileheader->linktype;
	//}
	//printfPcapFileHeader(pcapfileheader);
	//u_int8* pktdata = new u_int8;
	FILE* fp = fopen(filename.c_str(), "rb");
	if (fp == nullptr) {
		fprintf(stderr, "error---file can not open", filename);
		exit(-1);
	}

	u_int8 Buff[1480];
	//u_int8 Buff[MAX_ETH_SIZE] = {};
	fread(pcapfileheader, sizeof(pcapFileHeader_t), 1, fp);
	//int readsize=fread(Buff,1,)
	fread(ptk_header, sizeof(pcap_pkthdr), 1, fp);
	fread(framheader, sizeof(FramHeader_t), 1, fp);
	fread(ipheader, sizeof(IPHeader_t), 1, fp);
	fread(tcpheader, sizeof(TCPHeader_t), 1, fp); 
	fread(Buff, ptk_header->caplen - 54, 1, fp);
	//memset(Buff,0,sizeof(Buff));
	//memcpy(Buff, framheader, sizeof(framheader));
	//std::cout << sizeof(Buff) / sizeof(Buff[0])<<' ';
	//memcpy(Buff+14, ipheader, sizeof(ipheader));
	//std::cout << sizeof(Buff) / sizeof(Buff[0])<<' ';
	//memcpy(Buff+20, tcpheader, sizeof(tcpheader));
	//std::cout << sizeof(Buff) / sizeof(Buff[0])<<' ';
	//u_int8* ptk_data = Buff;
	//std::cout << std::endl;
	//packet_handle(ptk_header,Buff);
	//std::cout << std::endl;

	printfPcapFileHeader(pcapfileheader);
	std::cout << std::endl;
	printfPcapHeader(ptk_header);
	std::cout << std::endl;
	printfFameInfo(framheader);
	std::cout << std::endl;
	printfIpInfo(ipheader);
	std::cout << std::endl;
	printfTcpInfo(tcpheader);
	printfInfo(Buff, ptk_header->caplen - 54,havedata);


	delete pcapfileheader;
	delete ptk_header;
	delete framheader;
	delete ipheader;
	delete tcpheader;
	fclose(fp);
	return 0;
}