#pragma once
#include<WinSock2.h>
#include<Windows.h>
#include<fstream>
#include<iomanip>
#include"DataType.h"
#pragma comment(lib,"ws2_32.lib")
#pragma warning(disable:4996)
//#define MAX_ETH_SIZE 1512
static bool isftppacket = false;
static std::string username;
static std::string password;
static int num = 1;
std::string GetPcapFileName(const std::string Path) {
	//printf_s("File open successfully!");
	std::string fileName;
	if (Path.find("\\")==-1) {
		std::string::size_type ipos = Path.find_last_of('\\') + 1;
		fileName= Path.substr(ipos, Path.length() - ipos);
	}
	else {
		fileName = Path;
	}
	return fileName.c_str();
}

bool IsPcapFile(const std::string fileName) {
	bool ispcapfile = false;
	std::string suffix_str = fileName.substr(fileName.find_last_of ('.'));
	if (suffix_str == ".pcap" || suffix_str == ".cap") {
		ispcapfile = true;
	}
	return ispcapfile;
}


void StartToParse() {
	printf_s("Starting parse....\n");


}

void Menu() {
	StartToParse();
}

//void packet_handle(const struct pcap_pkthdr* header,const u_int8* pkt_data) {
//	bool is_get_a_ftp = false;
//	bool is_needout_info = true;
//	struct tm* ltime;
//	char timeStr[16];
//	IPHeader_t* Ipheader;
//	TCPHeader_t* Tcpheader;
//	FramHeader_t* Framheader;
//	//u_int32 Iplen;
//	u_int16 Srcport, Dstport;
//	time_t local_tv_sec;
//	int head = 54;
//	//ת��ʱ���ʽ
//	local_tv_sec = header->ts.tv_sec;
//	ltime = localtime(&local_tv_sec);
//	strftime(timeStr, sizeof(timeStr), "%H:%M:%S", ltime);
//
//	//��Ӧÿ����ͷ���е�ָ��ƫ������
//	Framheader = (FramHeader_t*)pkt_data;
//	Ipheader = (IPHeader_t*)(pkt_data + 14);
//	Tcpheader = (TCPHeader_t*)(pkt_data + 34);
//
//	std::string com;					//�趨���ܵ�״̬
//	for (auto i = 0; i < 4; i++) {
//		com += (char)pkt_data[54 + i];
//	}
//
//	std::string info;
//	Srcport = ntohs(Tcpheader->SrcPort);
//	Dstport = ntohs(Tcpheader->DstPort);
//
//	if (Srcport == 20 || Srcport == 21 || Dstport == 20 || Dstport == 21) {
//		if (header->len > 54) {			//��ȷ���Ƿ�Ϊ66
//			if (com == "USER") {
//				if (!username.length()) {
//					username.clear();	//��ֹuser���ݲ��ɾ�
//				}
//				is_get_a_ftp = true;
//				is_needout_info = false;
//				for (auto i = head + 5; pkt_data[i] != 13; i++) {	//u_int8 = 13Ϊ�س��ַ�
//					username += (char)pkt_data[i];
//				}
//				info = "Input username!";
//			}
//			else if (com == "PASS") {
//				if (!password.length()) {
//					password.clear();
//				}
//				is_get_a_ftp = true;
//				is_needout_info = false;
//				for (auto i = head + 5; pkt_data[i] != 13; i++) {
//					password += (char)pkt_data[i];
//				}
//				info = "Input password!";
//			}
//			else if (com == "230 " || com == "530 "|| com == "220 " || com == "331 " || com == "221 " ) {
//				is_get_a_ftp = true;
//				for (auto i = head; pkt_data[i] != 13; i++) {
//					info += (char)pkt_data[i];
//				}
//			}
//			printf_s("No.%d", num);
//			std::cout<<std::endl;
//			num++;
//			printf("%s.%.6d len:%d \n", timeStr, header->ts.tv_usec, header->len);
//
//			int length = sizeof(FramHeader_t) + sizeof(IPHeader_t);
//			if (Framheader->FrameType[1] == 0 && Framheader->FrameType[0] == 8) {//��Ϊ��IP֡
//				printf_s("Get An Ip Packet\n");
//				if (Ipheader->Protocol == 0x0006) {
//					printf_s("Get An TCP Packet\n");
//				}
//			}
//			//��ӡ������ܵ�����Ϣ
//			if (is_get_a_ftp) {
//				printf_s("user:%s, password:%s\n", username.c_str(), password.c_str());
//				if (is_needout_info) {
//					printf_s("info:%s", info.c_str());
//				}
//				std::cout << std::endl;
//			}
//			//��ӡ���MAC��ַ xx:xx:xx:xx��ʽ
//			for (auto i = 0; i < 6; i++) {
//				if (i != 5) {
//					printf_s("%02x:", Framheader->DstMAC[i]);
//				}
//				else {
//					printf_s("%02x", Framheader->DstMAC[i]);
//				}
//			}
//			printf_s(" <- ");
//			for (auto i = 0; i < 6; i++) {
//				if (i != 5) {
//					printf_s("%02x:", Framheader->SrcMAC[i]);
//				}
//				else {
//					printf_s("%02x:", Framheader->SrcMAC[i]);
//				}
//			}
//			std::cout << std::endl;
//			//��ʽ����ӡ���IP��ַ
//			//unsigned char SrcIP[16];
//			printf( "%d.%d.%d.%d ->", Ipheader->SrcIP.byte1, Ipheader->SrcIP.byte2, Ipheader->SrcIP.byte3, Ipheader->SrcIP.byte4);
//			//unsigned char DstIP[16];
//			printf( " %d.%d.%d.%d\n", Ipheader->DstIP.byte1, Ipheader->DstIP.byte2, Ipheader->DstIP.byte3, Ipheader->DstIP.byte4);
//			//printf_s("%s -> %s\n", SrcIP, DstIP);
//			
//			u_int8 flags = Tcpheader->Flags;
//			printf_s("SrcPort:%d -> DstPort:%d\n", Srcport, Dstport);
//			if (Srcport == 20 || Srcport == 21) {
//				printf_s("Server connect to Client\n");
//			}
//			else if (Dstport == 20 || Dstport == 21) {
//				printf_s("Client connect to Server\n");
//			}
//			//�ж�״̬
//			bool URG = flags & 0x20;
//			bool ACK = flags & 0x10;
//			bool PSH = flags & 0x08;
//			bool RST = flags & 0x04;
//			bool SYN = flags & 0x02;
//			bool FIN = flags & 0x01;
//			printf("URG=%d\nACK=%d\nPSH=%d\nRST=%d\nSYN=%d\nFIN=%d\n", URG, ACK, PSH, RST, SYN, FIN);
//			if (SYN) {
//				printf("����\n");
//			}
//			else if (FIN) {
//				printf("����\n");
//			}
//		}
//	}
//}

void printfPcapFileHeader(pcapFileHeader_t* pfhder) {
	if (pfhder == nullptr) {
		return;
	}
	printf("\tmagic:0x%0x\n\tversion_major:%u\n\tversion_minor:%u\n"
		"\tthiszone: % d\n\tsigfigs:%u\n\tsnaplen:%u\n\tlinktype:%u\n",
		pfhder->magic, pfhder->version_major, pfhder->version_minor,
		pfhder->thiszone, pfhder->sigfigs, pfhder->snaplen, pfhder->linktype);
}

void printfPcapHeader(pcap_pkthdr* ppkhder) {
	if (ppkhder == nullptr) {
		return;
	}
	printf("\ttime_sec :%u\n\ttime_usec :%u\n\tcapturelen :%u\n\tlen :%d",
		ppkhder->ts.tv_sec, ppkhder->ts.tv_usec, ppkhder->caplen, ppkhder->len);
}

void printfFameInfo(FramHeader_t* fhd) {
	if (fhd == nullptr) {
		return;
	}
	std::cout << std::endl;
	printf("\tDstMac: (%02x:%02x:%02x:%02x:%02x:%02x)\n\tSrcMac: (%02x:%02x:%02x:%02x:%02x:%02x)0 \n", 
		fhd->DstMAC[0], fhd->DstMAC[1], fhd->DstMAC[2],fhd->DstMAC[3], fhd->DstMAC[4], fhd->DstMAC[5], 
		fhd->SrcMAC[0], fhd->SrcMAC[1], fhd->SrcMAC[2], fhd->SrcMAC[3],fhd->SrcMAC[4], fhd->SrcMAC[5]);
	printf("\tFrameType : 0x%02x%02x", fhd->FrameType[0], fhd->FrameType[1]);
}

void printfIpInfo(IPHeader_t* Iphd) {
	if (Iphd == nullptr) {
		return;
	}
	std::cout << std::endl;
	//std::cout << std::hex << Iphd->Ver_HLen<<std::endl;
	printf("\tVersion : %d\n", (Iphd->Ver_HLen >> 4));
	printf("\tHead Len �� %d\n", (Iphd->Ver_HLen & 0x0f)*4);
	printf("\tTotal Len : %d\n", htons(Iphd->TotalLen));
	printf("\tDifferentiated Service Field : 0x%02x\n", Iphd->TOS);
	printf("\tIdentification : %d\n",htons(Iphd->ID));
	printf("\tFlags : 0x%04x\n", Iphd->Flag);
	printf("\tflagment offset : %d\n", Iphd->Segment);
	printf("\tTime to live : %d\n", Iphd->TTL);
	//printf("\tProtocol: %s\n", Iphd->Protocol == 6 ? "TCP" : "UDP");
	printf("\tProtocol : ");
	switch (Iphd->Protocol) {
	case 6:
		printf("TCP\n");
		break;
	case 17:
		printf("UPD\n");
		break;
	case 1:
		printf("ICMP\n");
		break;
	case 2:
		printf("IGMP\n");
		break;
	default:
		printf("Unknow\n");
		break;
	}
	printf("\tchecksum : %d\n", htons(Iphd->Checksum));
	printf("\tSrcIp : %d.%d.%d.%d\n", 
		Iphd->SrcIP.byte1, Iphd->SrcIP.byte2, Iphd->SrcIP.byte3, Iphd->SrcIP.byte4);
	printf("\tDstIp : %d.%d.%d.%d", 
		Iphd->DstIP.byte1, Iphd->DstIP.byte2, Iphd->DstIP.byte3, Iphd->DstIP.byte4);
}

void printfTcpInfo(TCPHeader_t* tcphd) {
	if (tcphd == nullptr) {
		return;
	}
	int srcPort = htons(tcphd->SrcPort);
	int dstPort = htons(tcphd->DstPort);
	printf("\tSrcPort : %d\n\tDstPort: %d",
		srcPort, dstPort);
	std::cout << std::setw(2) << std::setfill(' ') << "{" << std::endl;
	printf("\t\t\t Service type is");
	switch ((dstPort < srcPort) ? dstPort : srcPort) {
	case 80:printf(" http.\n");
		break;
	case 21: { printf(" ftp.\n");
		isftppacket = true;
		printf("\t\t\t");
		if (srcPort == 20 || srcPort == 21) {
			printf_s(" Server connect to Client.");
		}
		else if (dstPort == 20 || dstPort == 21) {
			printf_s(" Client connect to Server.");
		}
	}
		break;
	case 23:printf(" telnet.\n");
		break;
	case 25:printf(" smtp.\n");
		break;
	case 110:printf(" pop3.\n");
		break;
	case 443:printf(" https.\n");
		break;
	default:printf(" other.\n");
		break;
	}
	std::cout << std::endl << std::setw(23) << std::setfill(' ') << "}" << std::endl;

	printf("\tSequence Number(raw) : %d\n", htonl(tcphd->seqNO));
	printf("\tAcknowledgment Number(raw) : %d\n", htonl(tcphd->AckNO));
	printf("\tHeader Length : %d\n", (tcphd->tcp_hdlen_reserved >> 4) * 4);
	printf("\tFlags : 0x%02x", tcphd->Flags);

	std::cout << std::setw(2) << std::setfill(' ') << "{" << std::endl;
	printf("\t\t\t");
	if (tcphd->Flags & 0x08)  printf(" [���� PSH]");
	if (tcphd->Flags & 0x10)  printf(" [ȷ�� ACK] ");
	if (tcphd->Flags & 0x02)  printf(" [ͬ�� SYN]");
	if (tcphd->Flags & 0x20)  printf(" [���� URG]");
	if (tcphd->Flags & 0x01)  printf(" [��ֹ FIN]");
	if (tcphd->Flags & 0x04)  printf(" [��λ RST]");
	std::cout << std::endl << std::setw(22) << std::setfill(' ') << "}"<<std::endl;

	printf("\tWindows : %d\n", htons(tcphd->Window));
	printf("\tCheckSum : %d\n", htons(tcphd->Checksum));
	printf("\tUrgent Point : %d\n", htons(tcphd->UrgentPointer));


}
bool havedata(int len){
	return (len > 0? true : false);
}
void printfInfo(u_int8* data,int len,bool (*ptrfunc)(int)) {
	std::string com;//�趨���ܵ�״̬
	if (data != nullptr) {
		for (auto i = 0; i < 4; i++) {
			com += (char)data[i];
		}
	}
	else {
		return;
	}
	if (isftppacket && ptrfunc(len)) {
		std::string info;
		bool have_username = false;
		bool have_password = false;
		bool is_needout_info = false;
		if (com == "USER") {
			if (!username.length()) {
				username.clear();	//��ֹuser���ݲ��ɾ�
			}
			for (auto i =  5; data[i] != 13; i++) {	//u_int8 = 13Ϊ�س��ַ�
				username += (char)data[i];
			}
			info = "Input username!";
			have_username = true;
		}
		else if (com == "PASS") {
			if (!password.length()) {
				password.clear();
			}
			for (auto i =  5; data[i] != 13; i++) {
				password += (char)data[i];
			}
			info = "Input password!";
			have_password = true;
		}
		else if (com == "230 " || com == "530 " || com == "220 " || com == "331 " || com == "221 ") {
			for (auto i = 0; data[i] != 13; i++) {
				info += (char)data[i];
			}
			is_needout_info = true;
		}
		printf("\t\t\t");
		if (have_username && have_password) {
			printf_s("user:%s, password:%s\n", username.c_str(), password.c_str());
		}
		if (is_needout_info) {
			printf_s("info:%s", info.c_str());
		}
		std::cout << std::endl;
	}
}